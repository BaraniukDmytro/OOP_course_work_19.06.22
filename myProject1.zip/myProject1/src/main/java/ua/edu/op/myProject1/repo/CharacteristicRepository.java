package ua.edu.op.myProject1.repo;

import org.springframework.data.repository.CrudRepository;
import ua.edu.op.myProject1.Models.Characteristic;

public interface CharacteristicRepository extends CrudRepository<Characteristic, Long> {
}
