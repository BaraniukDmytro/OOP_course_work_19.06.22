package ua.edu.op.myProject1.Models;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Data
public class Characteristic {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String gender, age, growth, weight, additional;

    public Characteristic(){}

    public Characteristic(String gender, String age, String growth, String weight, String additional) {
        this.gender = gender;
        this.age = age;
        this.growth = growth;
        this.weight = weight;
        this.additional = additional;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGrowth() {
        return growth;
    }

    public void setGrowth(String growth) {
        this.growth = growth;
    }

    public String getWeight(){return weight;}

    public void setWeight(String weight){this.weight = weight;}

    public String getAdditional() {
        return additional;
    }

    public void setAdditional(String additional) {
        this.additional = additional;
    }
}
