package ua.edu.op.myProject1.Controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ua.edu.op.myProject1.Models.Workouts;
import ua.edu.op.myProject1.repo.WorkoutsRepository;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class WorkoutController {

    @Autowired
    private WorkoutsRepository workoutsRepository;

    @GetMapping("/workout")
    public String workoutMain(Model model){
        Iterable<Workouts> workouts = workoutsRepository.findAll();
        model.addAttribute("workouts",workouts);
        return "workout-main";
    }

    @GetMapping("/workout/add")
    public String workoutAdd(Model model){
        return "workout-add";
    }

    @PostMapping("/workout/add")
    public String workoutPostAdd(@RequestParam String name, @RequestParam String type, @RequestParam String level,
                                 @RequestParam String description, @RequestParam String trainer, Model model){
        Workouts workouts = new Workouts(name, type, level, description, trainer);
        workoutsRepository.save(workouts);
        return "redirect:/workout";
    }

    @GetMapping("/workout/{id}")
    public String workoutDetails(@PathVariable(value = "id") long id, Model model){
        if(!workoutsRepository.existsById(id)){
            return "redirect:/workout";
        }
        Optional<Workouts> workout = workoutsRepository.findById(id);
        ArrayList<Workouts> result = new ArrayList<>();
        workout.ifPresent(result::add);
        model.addAttribute("workout",result);
        return "workout-details";
    }

    @GetMapping("/workout/{id}/edit")
    public String workoutEdit(@PathVariable(value = "id") long id, Model model){
        if(!workoutsRepository.existsById(id)){
            return "redirect:/workout";
        }
        Optional<Workouts> workout = workoutsRepository.findById(id);
        ArrayList<Workouts> result = new ArrayList<>();
        workout.ifPresent(result::add);
        model.addAttribute("workout",result);
        return "workout-edit";
    }

    @PostMapping("/workout/{id}/edit")
    public String workoutPostUpdate(@PathVariable(value = "id") long id, @RequestParam String name, @RequestParam String type,
                                    @RequestParam String level, @RequestParam String description, @RequestParam String trainer,
                                    Model model){
        Workouts workouts = workoutsRepository.findById(id).orElseThrow();
        workouts.setName(name);
        workouts.setType(type);
        workouts.setLevel(level);
        workouts.setDescription(description);
        workouts.setTrainer(trainer);
        workoutsRepository.save(workouts);
        return "redirect:/workout";
    }

    @PostMapping("/workout/{id}/remove")
    public String workoutPostDelete(@PathVariable(value = "id") long id, Model model){
        Workouts workouts = workoutsRepository.findById(id).orElseThrow();
        workoutsRepository.delete(workouts);
        return "redirect:/workout";
    }

}
