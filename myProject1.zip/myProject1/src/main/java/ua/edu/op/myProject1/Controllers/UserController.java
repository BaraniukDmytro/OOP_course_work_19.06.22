package ua.edu.op.myProject1.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import ua.edu.op.myProject1.Models.User;
import ua.edu.op.myProject1.services.SecurityService;
import ua.edu.op.myProject1.services.UserService;
import ua.edu.op.myProject1.validators.UserValidator;

@Controller
public class UserController {
    private final UserService userService;
    private final UserValidator userValidator;
    private final SecurityService securityService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String Login(Model model, String error, String logout){

        if(error != null && !error.isEmpty()){
            model.addAttribute("error","username or password is incorrect");
        }
        if(logout != null){
            model.addAttribute("message","Logged out successfully");
        }

        return "login";
    }

    @Autowired
    public UserController(UserService userService, UserValidator userValidator, SecurityService securityService) {
        this.userService = userService;
        this.userValidator = userValidator;
        this.securityService = securityService;
    }


    // Передача браузеру страницы с формой
    @RequestMapping(value = {"/registration"}, method = RequestMethod.GET)
    public String registration(Model model) {
        model.addAttribute("userForm", new User());

        return "registration";
    }

    // Обработка данных формы
    @RequestMapping(value = "/registration", method = RequestMethod.POST)
    public String registration(@ModelAttribute("userForm") User user, BindingResult result, Model model) {

        // Валидация с помощью валидатора
        userValidator.validate(user, result);

        // Если есть ошибки - показ формы с сообщениями об ошибках
        if (result.hasErrors()) {
            return "registration";
        }

        // Сохранение пользователя в базе
        userService.save(user);

        //аутентификация
        securityService.autoLogin(user.getUsername(), user.getConfirmPassword());

        // Перенаправление на приветственную страницу
        return "redirect:/welcome";
    }

    @RequestMapping(value = {"/","/welcome"}, method = RequestMethod.GET)
    public String welcome(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String name = authentication.getName();

        model.addAttribute("username", name);
        return "welcome";
    }
}
