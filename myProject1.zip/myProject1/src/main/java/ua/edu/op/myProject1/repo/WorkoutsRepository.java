package ua.edu.op.myProject1.repo;

import org.springframework.data.repository.CrudRepository;
import ua.edu.op.myProject1.Models.Workouts;

public interface WorkoutsRepository extends CrudRepository<Workouts, Long> {

}
