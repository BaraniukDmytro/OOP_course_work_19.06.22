package ua.edu.op.myProject1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.edu.op.myProject1.Models.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
