package ua.edu.op.myProject1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;


@Service
public class SecurityService {

    private UserDetailsService userDetailsService;
    private AuthenticationManager manager;

    @Autowired
    public SecurityService(UserDetailsService userDetailsService, AuthenticationManager manager) {
        this.userDetailsService = userDetailsService;
        this.manager = manager;
    }

    public String findLoggedInUsername(){
        Object details = SecurityContextHolder.getContext().getAuthentication().getDetails();
        if(details instanceof UserDetails){
            UserDetails ud = (UserDetails) details;
            return ud.getUsername();
        }
        return null;
    }

    public void autoLogin(String username, String password){
        // Мы получим обьект стандартный User из UserDetailsService
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        // Сгенерируем специальный токен аутентификации
        UsernamePasswordAuthenticationToken token =
                new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());

        // Обратимся к менеджеру аутентификации и аутентифицируем токена
        manager.authenticate(token);

        // Аутентифицируем пользователя с помощью токена
        if(token.isAuthenticated()){
            SecurityContextHolder.getContext().setAuthentication(token);
        }
    }
}
