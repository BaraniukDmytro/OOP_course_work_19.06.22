package ua.edu.op.myProject1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.edu.op.myProject1.Models.User;


public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
