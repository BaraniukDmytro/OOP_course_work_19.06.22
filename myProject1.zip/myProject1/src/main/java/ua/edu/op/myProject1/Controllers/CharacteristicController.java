package ua.edu.op.myProject1.Controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ua.edu.op.myProject1.Models.Characteristic;
import ua.edu.op.myProject1.repo.CharacteristicRepository;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class CharacteristicController {
    @Autowired
    private CharacteristicRepository characteristicRepository;

    @GetMapping("/characteristic")
    public String characteristicMain(Model model){
        Iterable<Characteristic> characteristics = characteristicRepository.findAll();
        model.addAttribute("characteristic", characteristics);
        return "characteristic-main";
    }

    @GetMapping("/characteristic/add")
    public String characteristicAdd(Model model){
        return "add-characteristics";
    }

    @PostMapping("/characteristic/add")
    public String characteristicPostAdd(@RequestParam String gender, @RequestParam String age, @RequestParam String growth,
                                        @RequestParam String weight, @RequestParam String additional, Model model){
        Characteristic characteristic = new Characteristic(gender, age, growth, weight, additional);
        characteristicRepository.save(characteristic);
        return "redirect:/characteristic";
    }

    @GetMapping("/characteristic/{id}")
    public String characteristicDetails(@PathVariable(value = "id") long id, Model model){
        if(!characteristicRepository.existsById(id)){
            return "redirect:/characteristic";
        }
        Optional<Characteristic> characteristic = characteristicRepository.findById(id);
        ArrayList<Characteristic> result = new ArrayList<>();
        characteristic.ifPresent(result::add);
        model.addAttribute("workout",result);
        return "characteristic-details";
    }

    @GetMapping("/characteristic/{id}/edit")
    public String characteristicEdit(@PathVariable(value = "id") long id, Model model){
        if(!characteristicRepository.existsById(id)){
            return "redirect:/characteristic";
        }
        Optional<Characteristic> characteristic = characteristicRepository.findById(id);
        ArrayList<Characteristic> result = new ArrayList<>();
        characteristic.ifPresent(result::add);
        model.addAttribute("characteristic",result);
        return "characteristic-edit";
    }

    @PostMapping("/characteristic/{id}/edit")
    public String charactericticPostUpdate(@PathVariable(value = "id") long id, @RequestParam String gender, @RequestParam String age,
                                    @RequestParam String growth, @RequestParam String weight, @RequestParam String additional, Model model){
        Characteristic characteristic = characteristicRepository.findById(id).orElseThrow();
        characteristic.setGender(gender);
        characteristic.setAge(age);
        characteristic.setGrowth(growth);
        characteristic.setWeight(weight);
        characteristic.setAdditional(additional);
        return "redirect:/characteristic";
    }

    @PostMapping("/characteristic/{id}/remove")
    public String characteristicPostDelete(@PathVariable(value = "id") long id, Model model){
        Characteristic characteristic = characteristicRepository.findById(id).orElseThrow();
        characteristicRepository.delete(characteristic);
        return "redirect:/characteristic";
    }

}
